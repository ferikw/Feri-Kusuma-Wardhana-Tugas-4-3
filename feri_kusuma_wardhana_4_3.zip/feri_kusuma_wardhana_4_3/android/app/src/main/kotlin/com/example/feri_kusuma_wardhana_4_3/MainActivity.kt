package com.example.feri_kusuma_wardhana_4_3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
